echo "* Copying CSS"

echo "***** START";
cd ../../aether_subtheme/

echo "***** copying css into core";
cp -r ../aether_subtheme/css ../aether_core/;

echo "***** END";
