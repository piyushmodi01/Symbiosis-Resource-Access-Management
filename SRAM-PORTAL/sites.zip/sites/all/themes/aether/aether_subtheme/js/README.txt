Your theme can add JavaScript files in two ways:

To add a JavaScript file to all pages on your website, edit your sub-theme's
   .info file and add a line like this one:

     scripts[] = js/my-script.js
